import torch.nn as nn
import torch.nn.functional as F
from layers.adaptive_sd import sd_mc

class EncoderLayer(nn.Module):

    def __init__(self, attention, d_model, d_ff=None, avgpool_kernel=25, dropout=0.1, activation="relu"):#kernel_size1=25默认参数在位置参数后面。

        super(EncoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.attention = attention
        self.conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_ff, kernel_size=1, bias=False)
        self.conv2 = nn.Conv1d(in_channels=d_ff, out_channels=d_model, kernel_size=1, bias=False)
        self.series_decomp1 = sd_mc(avgpool_kernel, d_model)
        self.series_decomp2 = sd_mc(avgpool_kernel, d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x, af_assist, attn_mask=None):
        pass
        return None, None


class Encoder(nn.Module):

    def __init__(self, attn_layers, conv_layers=None, norm_layer=None):
        super(Encoder, self).__init__()
        self.attn_layers = nn.ModuleList(attn_layers)
        self.conv_layers = nn.ModuleList(conv_layers) if conv_layers is not None else None#debug这个为none
        self.norm = norm_layer

    def forward(self, x, af_assist, attn_mask=None):
        attns = []
        if self.conv_layers is not None:
            for attn_layer, conv_layer in zip(self.attn_layers, self.conv_layers):
                x, attn = attn_layer(x, af_assist, attn_mask=attn_mask)
                x = conv_layer(x)
                attns.append(attn)
            x, attn = self.attn_layers[-1](x)
            attns.append(attn)
        else:
            for attn_layer in self.attn_layers:
                x, attn = attn_layer(x, af_assist, attn_mask=attn_mask)
                attns.append(attn)

        if self.norm is not None:
            x = self.norm(x)

        return x, attns


class DecoderLayer(nn.Module):

    def __init__(self, self_attention, cross_attention, d_model, c_out, d_ff=None, avgpool_kernel=25, dropout=0.1, activation="relu"):
        super(DecoderLayer, self).__init__()
        d_ff = d_ff or 4 * d_model
        self.self_attention = self_attention
        self.cross_attention = cross_attention
        self.conv1 = nn.Conv1d(in_channels=d_model, out_channels=d_ff, kernel_size=1, bias=False)
        self.conv2 = nn.Conv1d(in_channels=d_ff, out_channels=d_model, kernel_size=1, bias=False)
        self.series_decomp1 = sd_mc(avgpool_kernel, d_model)
        self.series_decomp2 = sd_mc(avgpool_kernel, d_model)
        self.series_decomp3 = sd_mc(avgpool_kernel, d_model)
        self.dropout = nn.Dropout(dropout)
        self.projection = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=3, stride=1, padding=1, padding_mode='circular', bias=False)
        self.activation = F.relu if activation == "relu" else F.gelu

    def forward(self, x, cross, af_assist_dec, x_mask=None, cross_mask=None):
        pass
        return None, None


class Decoder(nn.Module):

    def __init__(self, layers, norm_layer=None, projection=None):
        super(Decoder, self).__init__()
        self.layers = nn.ModuleList(layers)
        self.norm = norm_layer
        self.projection = projection

    def forward(self, x, cross, af_assist_dec, x_mask=None, cross_mask=None, trend=None):

        for layer in self.layers:
            x, trend_part = layer(x, cross, af_assist_dec, x_mask=x_mask, cross_mask=cross_mask)
            trend = trend + trend_part


        if self.norm is not None:
            x = self.norm(x)

        if self.projection is not None:
            x = self.projection(x)
        return x, trend
