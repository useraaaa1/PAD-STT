import torch
import torch.nn as nn


class SGFilter(nn.Module):
    def __init__(self, window_length=5, polyorder=2):

        super(SGFilter, self).__init__()
        assert window_length % 2 == 1
        self.window_length = window_length
        self.polyorder = polyorder

    def forward(self, x: torch.Tensor) -> torch.Tensor:

        pass

        return None