
import torch.nn as nn
from layers.Embed import DataEmbedding_wo_pos, DataEmbedding_wo_pos_fourdim
from layers.EncDec import Encoder, Decoder, EncoderLayer, DecoderLayer
from layers.Norm import mynorm
from layers.denoising import SGFilter


class Model(nn.Module):

    def __init__(self, configs):
        super(Model, self).__init__()
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.output_attention = configs.output_attention

        self.sd_adptive = sd_mc_spe(configs.adapt_tre, configs.enc_in)
        self.sd_adptive_fourdim = sd_mc_fourdim(configs.adapt_tre, configs.enc_in)
        self.enc_embedding = DataEmbedding_wo_pos(configs.enc_in, configs.d_model, configs.embed, configs.freq, configs.dropout)#self.enc_embedding和self.dec_embedding都是类对象。
        self.dec_embedding = DataEmbedding_wo_pos(configs.dec_in, configs.d_model, configs.embed, configs.freq, configs.dropout)
        self.enc_embedding_fourdim = DataEmbedding_wo_pos_fourdim(configs.enc_in, configs.d_model, configs.embed, configs.freq, configs.dropout)

        self.dec_embedding_fourdim = DataEmbedding_wo_pos_fourdim(configs.dec_in, configs.d_model, configs.embed, configs.freq, configs.dropout)

        self.sg_filter = SGFilter(window_length=5, polyorder=2)



        self.encoder = Encoder(
            [EncoderLayer(AutoCorrelationLayer(AutoCorrelation(False, configs.factor, attention_dropout=configs.dropout, output_attention=configs.output_attention,
                                                                a_size=configs.a_size, cell_numer=configs.cell_numer, target=configs.target ), configs.d_model, configs.n_heads,
                                               root_path=configs.root_path, sid_path=configs.sid_path,
                                               gpu=configs.gpu, use_gpu=configs.use_gpu, use_multi_gpu=configs.use_multi_gpu, devices=configs.devices, target=configs.target),
                          configs.d_model, configs.d_ff, avgpool_kernel=configs.adapt_tre, dropout=configs.dropout,
                    activation=configs.activation) for l in range(configs.e_layers)], norm_layer=mynorm(configs.d_model) )

        self.decoder = Decoder(
            [
                DecoderLayer(
                    ACcorrelationLayer(ACcorrelation(True, configs.factor, attention_dropout=configs.dropout, output_attention=False,
                                                          a_size=configs.a_size, cell_numer=configs.cell_numer, target=configs.target),
                                         configs.d_model, configs.n_heads, root_path=configs.root_path, sid_path=configs.sid_path,
                                         gpu=configs.gpu, use_gpu=configs.use_gpu, use_multi_gpu=configs.use_multi_gpu, devices=configs.devices, target=configs.target),
                    ACcorrelationLayer(ACcorrelation(False, configs.factor, attention_dropout=configs.dropout, output_attention=False,
                                                          a_size=configs.a_size, cell_numer=configs.cell_numer, target=configs.target),
                                         configs.d_model, configs.n_heads, root_path=configs.root_path, sid_path=configs.sid_path,
                                         gpu=configs.gpu, use_gpu=configs.use_gpu, use_multi_gpu=configs.use_multi_gpu, devices=configs.devices, target=configs.target),
                    configs.d_model, configs.c_out, configs.d_ff, avgpool_kernel=configs.adapt_tre, dropout=configs.dropout, activation=configs.activation,
        ) for l in range(configs.d_layers)],norm_layer=mynorm(configs.d_model), projection=nn.Linear(configs.d_model, configs.c_out, bias=True))

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, af_assist, enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):

        pass

        if self.output_attention:
            return None
        else:
            return None